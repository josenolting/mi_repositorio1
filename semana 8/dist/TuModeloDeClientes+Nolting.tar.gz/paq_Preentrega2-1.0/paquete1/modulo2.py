import sys

cadena = sys.argv

print(cadena)