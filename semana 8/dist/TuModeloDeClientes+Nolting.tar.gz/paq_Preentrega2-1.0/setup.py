from setuptools import setup

setup(
    
    name= "paq_Preentrega2",
    version= "1.0",
    description= "Paquete para mi segunda Preentrega",
    packages = ["paquete1"],

)
